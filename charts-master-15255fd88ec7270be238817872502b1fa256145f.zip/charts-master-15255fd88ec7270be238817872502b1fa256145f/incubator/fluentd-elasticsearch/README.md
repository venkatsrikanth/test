# Fluentd Elasticsearch

**NOTE: this chart has been DEPRECATED. Please see stable/fluentd-elasticsearch
